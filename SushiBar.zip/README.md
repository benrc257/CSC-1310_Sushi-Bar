# Sushi Bar Game
This program is a lab we were assigned and we decided to make a program that would simulate a Sushi Bar conveyor restaurant.

## Description

Using RNG to generate random Sushi Dishes that come down the conveyor belt to the customer. AKA the player. You have a certain ammount of time to analyze the dish contents and make a decision on weather or not you want to take the Sushi. However, You are allowed to take up to 3 Sushi dishes and are only allowed up to 3 re-rolls if the dish does not appear to be appetizing enough. At the end of the game, you will have a total tab with Tax included, which is your score. You can pay out by closing the program, or you can continue the game and take more sushi till your hearts content.

## Authors

Benjamin Clark, Silas Garmon, Lucas Starkey, Alec Szczechowicz (Finished on 10/03/2024) *With Elegance*
